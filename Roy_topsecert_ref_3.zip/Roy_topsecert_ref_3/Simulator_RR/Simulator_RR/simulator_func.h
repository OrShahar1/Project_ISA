#ifndef _SIM_HPP
#define _SIM_HPP
#define _CRT_SECURE_NO_WARNINGS


#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <conio.h>

#define REGS_NUM 16 
#define MEM_SIZE 65536 
#define IMM_WIDTH 16 
#define REG_WIDTH 4 
#define OPCODE_WIDTH 4 

// Opcode number 
#define OP_ADD  0
#define OP_SUB  1
#define OP_AND  2
#define OP_OR   3
#define OP_SLL  4
#define OP_SRA  5
#define OP_LIMM  6
#define OP_BEQ  7
#define OP_BGT  8
#define OP_BLE  9
#define OP_BNE  10
#define OP_JAL  11
#define OP_LW   12
#define OP_SW   13
#define OP_JR  14
#define OP_HALT 15

// regs_type that contain the PC and all of the current regs

typedef struct Regs_type {
	int PC;
	int regs[REGS_NUM];
}Regs_type;

// Instr type that has all the five parametrs of the needed instruction
typedef struct Instr {
	int opcode, rd, rs, rt, imm;
}Instr;



void init_reg_file(Regs_type* reg_file);
void init_mem(FILE* mem_in, int* mem_arr);
Instr parse_instr(unsigned int line);
int run_inst(const Instr* instr, Regs_type* reg_file, int* mem);
void write_memout(FILE* memout, int* mem);
void write_count(FILE* count_file, int count);
void write_regs(FILE* regs_file, Regs_type* reg_file);
void write_state_trace(FILE* trace_file, Regs_type* reg_file, int inst);


#endif 
