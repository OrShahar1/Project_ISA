
#include "simulator_func.h"

void init_reg_file(Regs_type * reg_file) 
{
	int i = 0;
	reg_file->PC = 0;
	for (i = 0; i < REGS_NUM; ++i) {
		reg_file->regs[i] = 0;
	}
}
 
void init_mem(FILE* memin, int* mem_arr) {
	int mem_line_idx = 0;
	unsigned int read_from_file;
	do {
		
		if (fscanf(memin, "%x", &read_from_file) > 0){
			mem_arr[mem_line_idx++] = read_from_file;
			}
	} while (!feof(memin));
	
	for (; mem_line_idx < MEM_SIZE; ++mem_line_idx)
		mem_arr[mem_line_idx] = 0;
}

Instr parse_instr(unsigned int line) 
{
	Instr instr;
	instr.imm = line & 0xffff;
	if (instr.imm > (32768) - 1) {
		instr.imm = ~instr.imm + 1;
		instr.imm = (instr.imm & 0xffff)*(-1);
	}
	line >>= IMM_WIDTH;
	instr.rt = line & 0xf; line >>= REG_WIDTH;
	instr.rs = line & 0xf; line >>= REG_WIDTH;
	instr.rd = line & 0xf; line >>= REG_WIDTH;
	instr.opcode = line & 0xf;
	return instr;
}

int run_inst(const Instr* instr, Regs_type* reg_file, int* mem) {
	int rs = reg_file->regs[instr->rs];
	int rt = reg_file->regs[instr->rt];
	int rd = reg_file->regs[instr->rd];
	int imm = instr->imm;

	//operate the wanted opcode, diffrent between halt opcode, PC change opcode and "normal" opcode.
	switch (instr->opcode) {
	case OP_ADD:
		rd = rs + rt;
		break;
	case OP_SUB:
		rd = rs - rt;
		break;
	case OP_AND:
		rd = rs & rt;
		break;
	case OP_OR:
		rd = rs | rt;
		break;
	case OP_SLL:
		rd = rs << rt;
		break;
	case OP_SRA:
		rd = rs >> rt;
		break;
	case OP_LIMM:	
		rd=imm;
		break;
	case OP_BEQ:
		if (rs == rt) {
			reg_file->PC = imm;
			return 0;
		}
		break;
	case OP_BGT:
		if (rs > rt) {
			reg_file->PC = imm;
			return 0;
		}
		break;
	case OP_BLE:
		if (rs <= rt) {
			reg_file->PC = imm;
			return 0;
		}
		break;
	case OP_BNE:
		if (rs != rt) {
			reg_file->PC = imm;
			return 0;
		}
		break;
	case OP_JAL:
		reg_file->regs[15] = reg_file->PC + 1;
		reg_file->PC = imm;
		return 0;
	case OP_LW:
		rd = mem[rs + imm];
		break;
	case OP_SW:
		mem[rs + imm] = rd;
		break;
	case OP_JR:
	{
		reg_file->PC = rd;
		return 0;
	}
	break;
	case OP_HALT:
		return 1;
	}

	reg_file->PC++;
	if (instr->rd!=0)//check if the rd register is not the zero reg and update him
		reg_file->regs[instr->rd] = rd;
	return 0;

}

void write_memout(FILE* memout, int* mem) {
	int i = 0;
	for (i = 0; i < MEM_SIZE; ++i) {
		fprintf(memout, "%.8X\n", mem[i]);
	}
}

void write_count(FILE* count_file, int count) {
	fprintf(count_file, "%d\n", count);
}

void write_regs(FILE* regs_file, Regs_type* reg_file) {
	int reg_ndx = 0;
	for (reg_ndx = 0; reg_ndx < REGS_NUM; ++reg_ndx) {
		fprintf(regs_file, "%.8X\n", reg_file->regs[reg_ndx]);
	}
}

void write_state_trace(FILE* trace_file, Regs_type* reg_file, int inst) {
	int reg_ndx = 0;
	fprintf(trace_file, "%.8X", reg_file->PC);
	fprintf(trace_file, " %.8X", inst);
	for (reg_ndx = 0; reg_ndx < REGS_NUM; ++reg_ndx) {
		fprintf(trace_file, " %.8X", reg_file->regs[reg_ndx]);
	}
	fprintf(trace_file, "\n", reg_file->regs[reg_ndx]);
}
