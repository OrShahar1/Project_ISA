
#include "simulator_func.h"  

int main(int argc, char** argv) {
		Regs_type reg_file;
		int mem[MEM_SIZE];
		FILE *memin = NULL, *memout = NULL, *regout = NULL, *trace = NULL, *count = NULL;
		int flag_halt = 0, instr_num = 0;

		if (argc != 6)
		{
			printf("Wrong argv");
			return NULL;
		}

		memin = fopen(argv[1], "r");
		memout = fopen(argv[2], "w");
		regout = fopen(argv[3], "w");
		trace = fopen(argv[4], "w");
		count = fopen(argv[5], "w");
		if (NULL == memin || NULL == memout || NULL == regout || NULL == trace || NULL == count)//check if get the files correct
		{
			printf("Failed to read files");
			return;
		}
		init_reg_file(&reg_file);
		init_mem(memin, mem);

		while (!flag_halt) {
			Instr instr = parse_instr(mem[reg_file.PC]);//devide the instruction to opcode, registers and imm
			short imm = instr.imm;
			write_state_trace(trace, &reg_file, mem[reg_file.PC]);//write to trace
			flag_halt = run_inst(&instr, &reg_file, &mem);//run the instruction (check if is halt)
			instr_num++;

		}

		//write to files the needed parametrs 
		write_memout(memout, &mem);
		write_count(count, instr_num);
		write_regs(regout, &reg_file);


		fclose(memin);
		fclose(memout);
		fclose(regout);
		fclose(trace);
		fclose(count);
	
	return 0;
}
