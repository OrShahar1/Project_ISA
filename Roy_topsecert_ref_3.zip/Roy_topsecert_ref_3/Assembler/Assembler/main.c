#pragma warning(push,0)
#include "Header.h"


int main(int argc, char *argv[])
{
	FILE *Readpt = fopen(argv[1], "r");
	FILE *Writept = fopen(argv[2], "w");
	Label *Llist[MEM_LEN] = { 0 };
	int i = 0, j = 0, k, l = 0;
	int Max_Address = 0, Address, Word;
	int Opcode, PC = 0;
	unsigned int Inst[MEM_LEN] = { 0 };
	char Seg[500];
	char *Look4Label = NULL;


	if (!Readpt || !Writept)
	{
		printf("Files not found\n");
		return 1;
	}

	while (!feof(Readpt))
	{
		//here Assembly instruction are read and converted to machine language.
		//also, labels are stored in a separate struct and .word commands are stored in memory.
		memset(Seg, '\0', 100); //initializing a str to \0 so we can read it later after the assembly code is copied into it. this repeats many times throught the project
		fgets(Seg, 500, Readpt); //get assembly line
		Opcode = Assembler(Seg); //convert assembly to code
		if (Opcode == -1) //Label case
		{
			if (NULL == (Llist[l] = (Label*)malloc(sizeof(Label))))
			{
				printf("Error allocating memory.");
				Opcode == -2;
			}
			k = 0;
			memset(Llist[l]->Label_Name, '\0', sizeof(Llist[l]->Label_Name));
			while (Seg[k] != ':')
			{
				Llist[l]->Label_Name[k] = Seg[k++];
			}
			Llist[l]->Inst_Addr = PC;
			l++;
			k++;
			DeSpace(Seg, &k);
			if (isalpha(Seg[k]) != 0) // if there is an assembly line right after a label declaration
				Opcode = Assembler(&Seg[k]);
		}
		if (Opcode == -3)
		{
			//.word case. Word is placed in correct address and mark it in the Seg_Arrey.
			k = 0;
			DeSpace(Seg, &k);
			while (Seg[k] != ' ')
				k++;
			DeSpace(Seg, &k);
			Address = Get_Immediate(Seg, &k);
			DeSpace(Seg, &k);
			Word = Get_Immediate(Seg, &k);
			Inst[Address] = Word;
			if (Address>Max_Address)
			{
				Max_Address = Address;
			}
		}
		else if (Opcode != -2 && Opcode != -1)
			//Valid Inst. opcode saved in the PC address and printed for validation. (note that in line branching to a label, the code printed will not be entirely correct yet)
		{
			printf("0x%08x\n", Opcode);
			Inst[PC] = Opcode;
			PC++;
		}
		else
		{
			printf("Invalid Inst\n");
		}
	}

	PC = 0;
	Readpt = fopen(argv[1], "r");

	while (!feof(Readpt))
	{
		//Labels are read from stored positions and put in the correct lines
		memset(Seg, '\0', 100);
		fgets(Seg, 200, Readpt);
		l = Assembler(Seg);
		k = 0;
		if (l == -1)
		{
			DeSpace(Seg, &k);
			while (Seg[k] != ':')
			{
				k++;
			}
			k++;
			DeSpace(Seg, &k);
			if (isalpha(Seg[k]) != 0) //checking if after label there is a assembly line.
				l = Assembler(&Seg[k]);
		}
		if (l != -1 && l != -2 && l != -3)
		{
			//Regular instraction.
			Look4Label = Connect_Label(&Seg[k]);
			if (Look4Label != NULL)
			{
				Address = Search_Laddress(Llist, Look4Label);
				Inst[PC] += Address;
				free(Look4Label);
			}
			PC++;
		}
	}
	//Updates the max address to know how much addresses to print.
	if (PC>Max_Address)
	{
		Max_Address = PC;
	}

	for (i = 0; i <= Max_Address; i++)
	{
		printf("%08X\n", Inst[i]);
		fprintf(Writept, "%08X\n", Inst[i]);
	}

	fclose(Readpt);
	fclose(Writept);
	return 0;
}





#pragma warning (pop)