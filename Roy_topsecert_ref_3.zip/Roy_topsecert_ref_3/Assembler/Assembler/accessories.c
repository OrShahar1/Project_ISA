#include "Header.h"

#pragma warning(push,0)

int HxToInt(char str[]) //change hexa to decimal num
{
	long i = 0, Value = 0, temp = 0;
	char c = 0;

	for (i = 0; i < strlen(str); i++)
	{
		c = str[i];
		if (str[i] >= '0' & str[i] <= '9')
		{
			Value = Value * 16 + str[i] - '0';
		}
		else if (str[i] >= 'A' & str[i] <= 'F')
		{
			temp = str[i] - 'A' + 10;
			Value = Value * 16 + str[i] - 'A' + 10;
		}
		else if (str[i] >= 'a' & str[i] <= 'f')
		{
			temp = str[i] - 'a' + 10;
			Value = Value * 16 + str[i] - 'a' + 10;
		}
	}
	return Value;
}


//Get source string and pointer i and promote it until no spaces or tabs.
void DeSpace(char *Source, int *i)
{
	while ((Source[*i] == ' ' || Source[*i] == '	') & Source[*i] != '\0')
	{
		(*i)++;
	}

}

// copy a string content to target until end1/end2/'\0'/#/'\n' encountered. also promoted index "Begin" to the last index copied
void Get_Word(char *str, int *Begin, char *Target, char end1, char end2)
{
	int j = 0;

	while ((str[*Begin] != end1) & str[*Begin] != end2 & (str[*Begin] != '\0') & (str[*Begin] != '#') & (str[*Begin] != '\n'))
	{

		Target[j] = str[*Begin];
		(*Begin)++;
		j++;
	}

}

//check if Label1 exists in the label list and if so return the adress saved to it.
int Search_Laddress(Label *Label_List[MEM_LEN], char *Label1)
{
	int i, j;
	char temp[100] = { 0 };
	char temp2[100] = { 0 };

	for (i = 0; i<MEM_LEN; i++)
	{
		memcpy(temp, Label1, 100);
		if (!Label_List[i]->Label_Name)
		{
			printf("Error: label does not exist");
			return 0;
		}
		j = strlen(Label1);
		j = memcmp(Label_List[i]->Label_Name, Label1, j);
		if (!j)
			return Label_List[i]->Inst_Addr;
	}
	return 0;
}

//a code is received. func decides if it's a register or op code and translates it to the correct number
int Get_Code(char *String)
{
	if (String[0] == '$')
		return Generate_Reg_Code(String);
	else
		return Generate_Op_Code(String);
}

int Generate_Op_Code(char *Operator)
{
	char OpDef[16][5] = { "add", "sub", "and","or","sll","sra","limm","beq","bgt","ble","bne","jal","lw","sw","jr","halt" }; //check if op is legal and returns index which equals correct code.
	int i = 0;
	if (!strcmp(Operator, ".word"))
		return 20;
	for (i = 0; i < 16; i++)
	{
		if (!strcmp(Operator, OpDef[i]))
			return i;
	}
	i = 0;
	while (isalpha(Operator[i]) != 0 || (Operator[i] >= '0' && Operator[i] <= '9')) //check if label
		i++;
	if (Operator[i] == ':')
		return 16; //label
	else return 17; //invalid op
}

////check if reg is legal and returns index which equals correct code.
int Generate_Reg_Code(char *Reg)
{
	char RegDef[16][6] = { "$zero", "$at", "$v0","$a0","$a1","$t0","$t1","$t2", "$t3","$s0","$s1","$s2","$gp","$sp","$fp","$ra" };
	int i = 0;
	for (i = 0; i < 16; i++)
	{
		if (!strcmp(Reg, RegDef[i]))
			return i;
	}
	return 16;
}

//get the immidiate in string type and return int
int Get_Immediate(char *str, int *i)
{
	int j = *i, temp = *i;
	int k = 0;
	int Sign = 1;
	char imm[9] = { 0 };


	if (str[j] == '-')
	{
		j++;
		Sign = -1;
	}

	if (str[j] == '0' & str[j + 1] == 'x' || str[j] == '0' & str[j + 1] == 'X') //if hexa, translate to dec
	{
		j = j + 2;
		while (isdigit(str[j]) || isalpha(str[j]))
		{
			imm[k] = str[j];
			k++;
			j++;
		}
		*i = j;
		int number = HxToInt(imm);
		return Sign*number;

	}
	else if (isalpha(str[j])) //if label return 0 and wait for the rest of the code
		return 0;
	else
	{
		while (isdigit(str[j])) //if digits, just return them
			imm[k++] = str[j++];
		*i = j;

		return Sign*atoi(imm);
	}


}

//check if assembly line contains label as immediate and return a pointer to a str containing the label


char *Connect_Label(char *str)
{
	int i = 0, j = 0;
	char *Label;
	if (NULL == (Label = (char*)malloc(sizeof(char) * 50)))
	{
		printf("Error allocating memory");
		return Label;
	}
	memset(Label, '\0', 50);
	for (j = 0; j < 3; j++)
	{
		while (str[i] != ',' & str[i] != '\0')
			i++;
		if (str[i] == '\0')
			return Label;
		i++;
	}

	DeSpace(str, &i);
	Get_Word(str, &i, Label, ' ', 9);

	//If there is a letter in the begining of the last word it is label.
	if (isalpha(Label[0]))
	{
		return Label;
	}
	return NULL;


}


#pragma warning (pop)