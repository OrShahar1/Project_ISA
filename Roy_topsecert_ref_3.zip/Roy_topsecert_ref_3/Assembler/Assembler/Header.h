#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

typedef struct label
{
	char Label_Name[100];
	int Inst_Addr;
}Label;

#define MEM_LEN 65000

//65536