#pragma warning(push,0)
#include "Header.h"

//get an assembly line and conver to opcode. if it is a label returns -1 if it is .word inst return -3
int *Assembler(char *str) //delet arg

{
	int i = 0, Opcode = 0, Operator_Code, Reg_Code, k = 0;
	char Operator[20] = { 0 };
	char Reg[7] = { 0 };
	char imm[10] = { 0 };
	int Sign = 1;
	unsigned short Imm;

	//delet spaces before operator
	DeSpace(str, &i);
	//get operator name
	Get_Word(str, &i, Operator, ' ', '	');
	Opcode = Get_Code(Operator);

	//check if label or invalid operator
	if (Opcode == 16) //label
	{
		return -1;
	}
	else if (Opcode == 17) //invalid
	{
		return -2;
	}
	else if (Opcode == 20) //.word
	{
		return -3;
	}
	for (k = 0; k < 3; k++) //get registers
	{
		DeSpace(str, &i);
		memset(Reg, '\0', 7);
		Get_Word(str, &i, Reg, ',', ' ');
		Reg_Code = Get_Code(Reg);
		if (Reg_Code == 16)
		{
			return -2;
		}
		Opcode = (Opcode << 4) + Reg_Code;
		DeSpace(str, &i);
		//validation check
		if (!str[i] == ',')
			return -2;// Invalid code
		else
			i++;
	}
	DeSpace(str, &i);
	Imm = Get_Immediate(str, &i);
	Opcode = (Opcode << 16) + Imm;
	return Opcode;

}
#pragma warning (pop)