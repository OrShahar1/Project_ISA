/*Assembler code by Yonatan Rudin & Yarin Kimor*/
#pragma warning(disable:4996)
#include <stdio.h>
#include <stdlib.h> //atoi(), exit(), strtol() libary
#include <string.h> //strcmp(), strncpy(), strcpy() libary
#include <ctype.h> //isalpha(), isdigit() libray
#include <stdint.h> //32 bit intigers
#include <math.h>//power calculation

#define MAX_LINE_LENGTH		500
#define MAX_FILE_LENGTH     4096	
#define MAX_LABEL_LENGTH	50

enum command_field {
	op_code,
	rd,
	rs,
	rt,
	rm,
	imm,
	save_to_print,
	dot_word
};


///////*label dictonary*/////////
struct label_id {
	char label[MAX_LABEL_LENGTH];
	int address;
};
struct label_id label_dict[MAX_FILE_LENGTH];
////////////////////////////////
//temporary command fields 
int pc_counter = 0;
int temp_op_code = 0;
int temp_rd = 0;
int temp_rs = 0;
int temp_rt = 0;
int temp_rm = 0;
int temp_imm = 0;
int labels_counter = 0;//to know how much labeles there are in the code

enum command_field command_field_pointer = op_code; //not actually a pointer

//array of command names-array of char pointers. each pointer points to an array of chars that contains the name
//of the appropriate command name.
const char *commands_names[] = { "add",
								  "sub",
								  "and",
								  "or",
								  "sll",
								  "sra",
								  "mac",
								  "branch",
								  "reserved1",
								  "reserved2",
								  "reserved3",
								  "jal",
								  "lw",
								  "sw",
								  "jr",
								  "halt",
								  ".word" };

//array of registers names-array of char pointers. each pointer points to an array of chars that contains the name
//of the appropriate register.
const char *registers_names[] = { "$zero",
								  "$at",
								  "$v0",
								  "$a0",
								  "$a1",
								  "$t0",
								  "$t1",
								  "$t2",
								  "$t3",
								  "$s0",
								  "$s1",
								  "$s2",
								  "$gp",
								  "$sp",
								  "$fp",
								  "$ra" };

/*function declaration*/
//this function runs the second run on the asm code and generates the memory image output file
//the function gets pointer to the asm file and argc argv arguments
void second_run(FILE* f_asm, int argc, char* argv[]);
/*this function converts assembler command to it's match operational code*/
/*the function gets the buffer from the last reading of the file*/
//returns 0 if - nothing matched
//returns -1 if label and not command
//returns -2 if .word command
//returns -3 if if it's comment and not command
int command_to_op_code(char buff[]);
/*converting $reg_name to it's matching register number*/
//the functions returns the reg num or num if rm case in bracnch commands
int register_to_code(char buff[]);
/*identifies if imm is a numbber, a label or a Hex digits*/
/*if number - returns its value*/
/*if hex -returns its integer value*/
/*if label - search in the label dictionary to find which address the label is , replace label name with it's address*/
int imm_identifier(char buff[]);
/*this function saves all the labels names and it's address*/
/*the function gets the file location to read in the file to read string*/
/*the function returns zero when dones*/
int fill_label_dict(char file_to_read[]);
/*converts array to string for .word command only - can work with 32 bit integer for getting all 32bits needed range */
//the functions gets string to convert and base that the data in the string is writen
//the functions returns the in value of the string 
uint32_t str_array_to_int(char dot_word_buff[], int base);
/*the function prints the results to the file*/
/*she gets the buffer to print and the name and location of the output file*/
/*the function returns 0 when done*/
int print_to_file(int print_to_file_buff[], char output_file[]);
/*converts str to lower case only*/
/*the function gets string and retuns 0 when done*/
int strtolowercase(char str[]);
/////////////////////////

int main(int argc, char* argv[])
{
	fill_label_dict(argv[1]);// this function scaning the assembler code for lables, saves at dictonary the label and its address

	FILE *f_asm = fopen(argv[1], "r");//file to read
	if (f_asm == NULL)//check if file opened
	{
		printf("Error opening file!\n");
	}
	second_run(f_asm, argc, argv);//run for the second time on the asm file and generates memory image

	fclose(f_asm);//close the asembler file
	system("pause");//to prevent closing the console window
	return(0);
}




///////////////////////////////////////////////Functions Area////////////////////////////////////////////////////////////////
//this function runs the second run on the asm code and generates the memory image output file
//the function gets pointer to the asm file and argc argv arguments
void second_run(FILE* f_asm, int argc, char* argv[])
{

	int i = 0;
	int s = 0;
	char buff[MAX_LINE_LENGTH] = { 0 };//array of chars meant to hold an entire line from the given asm file
	char dot_word_buff[8];//temporary array used to store the hexadecimal data in the case of a .word command

	/*an array meant to store the numerical values of each segment of a command in integer format before writing
	to output file memin. 6 fields for each command * number of maximum memory cells. */
	int print_to_file_buff[MAX_FILE_LENGTH * 6] = { 0 }; //for clarification see documentation.
	char temp_imm_buff[MAX_LINE_LENGTH];
	int offset = 0;

	int printing_array_pointer = 0;

	int dot_word_address = 0;
	uint32_t dot_word_data = 0;

	int EOF_flag = 0;// asserted when scanf() return EOF end of file

	int y = 0;//used in case imm to clear the buffer from white spaces
	int cnt = 0;//counter used for temp imm buffer to fill without white spaces
	//////////////////////////////////////////////////////////////////////////
	while (EOF_flag != 1)
	{
		switch (command_field_pointer)
		{
		case op_code:
			offset = 0;
			char buff[MAX_LINE_LENGTH] = { 0 };//array of chars meant to hold an entire line from the given asm file//newwwwww
			if (fscanf(f_asm, "%s", buff) == EOF)//read a word, check if the file ended, [^ ^	^:^\n^,]
			{
				EOF_flag = 1;// file ended
				print_to_file(print_to_file_buff, argv[2]);//print the printing buffer to the file
				break;
			}
			strtolowercase(buff);

			if (buff[0] == '#')//in case of multipal comments lines
			{
				fgets(buff, MAX_LINE_LENGTH, f_asm);//read the whole data after # and discard it
				offset = 0;
				command_field_pointer = op_code;
				break;
			}

			int i = 0;
			for (i = 0;i <= MAX_LINE_LENGTH;i++)//handle LABEL:command
			{
				if (buff[i] == ':')
				{
					if (buff[i + 1] != '\0')
					{
						offset = i + 1;
					}
					else
					{
						command_field_pointer = op_code;
						offset = 0;
						break;
					}
				}
			}
			for (i = 0;i <= (MAX_LINE_LENGTH - offset);i++)//start the buffer after the ':'
			{
				if (offset != 0)
				{
					buff[i] = buff[i + offset];
				}
			}
			if (buff[0] == '#')//in case of multipal comments lines
			{
				fgets(buff, MAX_LINE_LENGTH, f_asm);//read the whole data after # and discard it
				offset = 0;
				command_field_pointer = op_code;
				break;
			}

			temp_op_code = command_to_op_code(buff);//search for op_code
			if (temp_op_code == -1)//label was found. need to read again to read the command
			{
				command_field_pointer = op_code;//labels are invisible in the 2nd file scan - read again for command
				offset = 0;
				break;
			}
			if (temp_op_code == -2)//.word command was found. 
			{
				command_field_pointer = dot_word;
				break;
			}
			command_field_pointer = rd;//no label or .word function, go to next command field
			break;
		case rd:
			fscanf(f_asm, "%[^$]s", buff);//pointer stuck on $
			fscanf(f_asm, "%[^,^ ^	^\n]s", buff);//read until , or space
			strtolowercase(buff);
			fgetc(f_asm);//to make the pointer not stuck on the ','- this increment the pointer to next char
			temp_rd = register_to_code(buff);
			command_field_pointer = rs;
			break;
		case rs:
			fscanf(f_asm, "%[^$]s", buff);//pointer stuck on $
			fscanf(f_asm, "%[^,^ ^	^\n]s", buff);//read until , or spaceor tab
			strtolowercase(buff);
			fgetc(f_asm);//to make the pointer not stuck on the ',', this increment the pointer to next char
			temp_rs = register_to_code(buff);//translate the register name to register number 
			command_field_pointer = rt;
			break;
		case rt:
			fscanf(f_asm, "%[^$]s", buff);//pointer stuck on $
			fscanf(f_asm, "%[^,^ ^	^\n]s", buff);//read until , or space or tab
			strtolowercase(buff);
			fgetc(f_asm);//to make the pointer not stuck on the ',', this increment the pointer to next char
			temp_rt = register_to_code(buff);//translate the register name to register number 
			command_field_pointer = rm;
			break;
		case rm:
			fscanf(f_asm, "%[^$^0^1^2^3^4^5]s", buff);//pointer stuck on $//the nuber is for branch commands
			fscanf(f_asm, "%[^,^ ^	^\n]s", buff);//read until , or space or tab
			strtolowercase(buff);
			fgetc(f_asm);//to make the pointer not stuck on the ',', this increment the pointer to next char
			temp_rm = register_to_code(buff);//translate the register name to register number 
			command_field_pointer = imm;
			break;
		case imm:
			cnt = 0;
			fgets(buff, MAX_LINE_LENGTH, f_asm);//read the whole line
			strtolowercase(buff);
			for (y = 0; y <= MAX_LINE_LENGTH; y++)//copy without space and tabs 
			{
				if ((buff[y] != ' ') && (buff[y] != '	') && (buff[y] != ',') && (buff[y] != '\n'))//dont copy white spaces and , to temp imm buff
				{
					temp_imm_buff[cnt] = buff[y];
					cnt = cnt + 1;
				}
			}
			for (y = 0; y <= MAX_LINE_LENGTH; y++)//search for the end of the imm field
			{
				if (temp_imm_buff[y] == '#')
				{
					temp_imm_buff[y] = '\0';
					break;
				}
			}
			temp_imm = imm_identifier(temp_imm_buff);
			command_field_pointer = save_to_print;	//go to next command field	
			break;
		case save_to_print:
			/*save all command field data to array buffer before printing*/
			print_to_file_buff[printing_array_pointer] = temp_op_code;
			print_to_file_buff[printing_array_pointer + 1] = temp_rd;
			print_to_file_buff[printing_array_pointer + 2] = temp_rs;
			print_to_file_buff[printing_array_pointer + 3] = temp_rt;
			print_to_file_buff[printing_array_pointer + 4] = temp_rm;
			print_to_file_buff[printing_array_pointer + 5] = temp_imm;
			printing_array_pointer = printing_array_pointer + 6;
			command_field_pointer = op_code;
			break;
		case dot_word:
			/*this state handles  with .word command*/
			fscanf(f_asm, "%s", buff);//address field - no danger of integer overflow
			strtolowercase(buff);
			if (buff[0] == '0' && buff[1] == 'x')//a hex number
			{
				strncpy(dot_word_buff, buff + 2, 4);//copy the hex digits to temp_buff withouts '0x' chars. 4 BEACAUSE 3 DIGITS AND \0
				dot_word_address = (int)strtol(dot_word_buff, NULL, 16);
			}
			else
			{
				dot_word_address = atoi(buff);//convert buffer chars to integer
			}
			fscanf(f_asm, "%s", buff);//data_field - danger of integer overflow - gets a special care
			strtolowercase(buff);
			for (i = 0; i <= MAX_LINE_LENGTH; i++)//end the buff in comment area
			{
				if (buff[i] == '#')
				{
					buff[i] = '\0';
					break;
				}
			}
			if (buff[0] == '0' && buff[1] == 'x')//a hex number
			{
				strncpy(dot_word_buff, buff + 2, 9);//copy the hex digits to temp_buff withouts '0x' chars. 9 BEACAUSE 8 DIGITS AND \0
				dot_word_data = str_array_to_int(dot_word_buff, 16);//(array,base)
			}
			else  //not hex format - decimal format
			{
				if (buff[0] == '-')
				{
					strncpy(dot_word_buff, buff + 1, 20);
					dot_word_data = str_array_to_int(dot_word_buff, 10);//negative number
					dot_word_data = -1 * dot_word_data; //make it negative
				}
				else
				{
					dot_word_data = str_array_to_int(buff, 10); //positive number
				}

			}

			/*bitwise masking - to match 32bit data from .word to command field printing array method*/
			print_to_file_buff[6 * dot_word_address] = (dot_word_data & 0xF0000000) >> 28;//LOGICAL SHIFT
			print_to_file_buff[6 * dot_word_address + 1] = (dot_word_data & 0x0F000000) >> 24;
			print_to_file_buff[6 * dot_word_address + 2] = (dot_word_data & 0x00F00000) >> 20;
			print_to_file_buff[6 * dot_word_address + 3] = (dot_word_data & 0x000F0000) >> 16;
			print_to_file_buff[6 * dot_word_address + 4] = (dot_word_data & 0x0000F000) >> 12;
			print_to_file_buff[6 * dot_word_address + 5] = dot_word_data & 0x00000FFF;
			command_field_pointer = op_code;
			break;
		default:
			break;
		};
	}
}

/*this function converts assembler command to it's match operational code*/
/*the function gets the buffer from the last reading of the file*/
//returns 0 if - nothing matched
//returns -1 if label and not command
//returns -2 if .word command
//returns -3 if if it's comment and not command
/*==================================================================*/
int command_to_op_code(char buff[])
{
	int x = 0;//index for loop
	/*there are 15 regular commands, .word command. searching which command recieved  */
	for (x = 0; x <= 16; x++)
	{
		if (strcmp(buff, commands_names[x]) == 0)//strcmp returns 0 if equal
		{
			if (x == 16)// .word command found
			{
				return(-2);//.word command found return value
			}
			pc_counter = pc_counter + 1;//command found
			return(x);
		}
		if (x == 16 && strcmp(buff, commands_names[x]) != 0)
		{
			if (buff[0] != '#')
			{
				pc_counter = pc_counter + 1;//changed today may problem
				return(-1);//label found return value
			}
			else
			{
				return(-3);//just a multipal comment
			}
		}
	}
	return(0);//if nothing matched - not a desiered state
}
/*==================================================================*/


/*converting $reg_name to it's matching register number*/
//the functions returns the reg num or num if rm case in bracnch commands
/*==================================================================*/
int register_to_code(char buff[])
{
	int y = 0;
	/*searching for matching register name in the registers names bank*/
	for (y = 0;y <= 15;y++)
	{
		if (strcmp(buff, registers_names[y]) == 0)//strcmp returns 0 if equal
			return(y); // may need to add condition when nothing equal

	}
	return(atoi(buff));//if number instead of register name. only in rm reg field (branch command) atoi converts string to int
}
/*==================================================================*/


/*identifies if imm is a numbber, a label or a Hex digits*/
/*if number - returns its value*/
/*if hex -returns its integer value*/
/*if label - search in the label dictionary to find which address the label is , replace label name with it's address*/
/*==================================================================*/
int imm_identifier(char buff[])
{
	int i;
	char temp_buff[MAX_LINE_LENGTH];
	if (buff[0] == '0' && buff[1] == 'x')//a hex number
	{
		strncpy(temp_buff, buff + 2, 4);//copy the hex digits to temp_buff withouts '0x' chars
		return((int)strtol(temp_buff, NULL, 16)); // hex to integer //long int strtol(const char *str, char **endptr, int base)	      
	}
	if (isalpha(buff[0]))// a label - to check if '-' can make a problen with isalpha
	{
		for (i = 0; i <= labels_counter;i++)//search in the label dictionary for matching label
		{
			if (strcmp(buff, label_dict[i].label) == 0)//strcmp returns 0 if equal
			{
				return(label_dict[i].address);//matching label found, return its address
			}
		}
	}
	if (isdigit(buff[0]) || buff[0] == '-')//a number, or negative number
	{
		if (buff[0] == '-')
		{
			strncpy(buff, buff + 1, 4);//copy without the negative sign
			return(-1 * atoi(buff));//converts chars array to integer value
		}
		else
		{
			return(atoi(buff));//converts chars array to integer value	
		}
	}
	return(0);//if nothing matched - not a desired case
}
/*==================================================================*/




/*this function saves all the labels names and it's address*/
/*the function gets the file location to read in the file to read string*/
/*the function returns zero when dones*/
int fill_label_dict(char file_to_read[])
{
	FILE *f_asm = fopen(file_to_read, "r");//file to read
	char buff2[MAX_LINE_LENGTH];
	char temp_buff2[MAX_LINE_LENGTH];
	int i = 0;
	int psik_cnt = 0;
	int row_cnt = 0;
	int current_row_cnt = 0;

	if (f_asm == NULL)//check if file opened
	{
		printf("Error opening file!\n");
	}

	int EOF_flag2 = 0;// asserted when scanf() return EOF end of file


	while (EOF_flag2 != 1)//do if not end of file
	{
		if (fgets(buff2, MAX_LINE_LENGTH, f_asm) == NULL)//read a line
		{
			EOF_flag2 = 1;// file ended
			break;
		}
		strtolowercase(buff2);
		current_row_cnt = row_cnt;
		int a = 0;

		for (i = 0; i <= MAX_LINE_LENGTH; i++)//end the buff in comment area
		{
			if (buff2[i] == '#')
			{
				buff2[i] = '\0';
				break;
			}
		}

		for (i = 0; i <= MAX_LINE_LENGTH; i++)//copy data without whitespaces
		{
			if (buff2[i] != '	' && buff2[i] != ' ')
			{
				temp_buff2[a] = buff2[i];
				a = a + 1;
				if (buff2[i] == '\0')
				{
					temp_buff2[a] = '\0';
					a = 0;
					break;
				}
			}
			if (buff2[i] == ',')// after every 4 psiks the pc counter neet to increment
			{
				psik_cnt = psik_cnt + 1;
				if (psik_cnt == 4)
				{
					psik_cnt = 0;
				}
				if (psik_cnt == 0)
				{
					row_cnt = row_cnt + 1;
				}
			}
		}
		a = 0;

		for (i = 0;i <= MAX_LINE_LENGTH;i++)//end of label
		{
			if (temp_buff2[i] != '\0')
			{
				if (temp_buff2[i] == ':')
				{
					temp_buff2[i] = '\0';
					strcpy(label_dict[labels_counter].label, temp_buff2);//save label name at dictionary
					label_dict[labels_counter].address = current_row_cnt;// save label address at dictionary
					labels_counter = labels_counter + 1;
				}
			}
			else
				break;
		}

	}
	fclose(f_asm);//close the asembler file
	return(0);//label dictnary updated done
}



/*==================================================================*/

/*converts array to string for .word command only - can work with 32 bit integer for getting all 32bits needed range */
//the functions gets string to convert and base that the data in the string is writen
//the functions returns the in value of the string 
/*==================================================================*/
uint32_t str_array_to_int(char dot_word_buff[], int base)
{
	uint32_t value = 0;
	int i = 0;
	int buff_end = 0;
	int x = 0;
	char temp_str[2];
	for (i = 0; i <= MAX_LINE_LENGTH; i++)//search buffer end
	{
		if (dot_word_buff[i] == '\0')
		{
			buff_end = i;
			break;
		}
	}
	for (i = buff_end - 1; i >= 0; i--)
	{
		temp_str[0] = '0';//to manipulate strtol
		temp_str[1] = dot_word_buff[i];
		value = value + ((int)pow(base, x)*(int)strtol(temp_str, NULL, base));
		x = x + 1;
	}
	return(value);
}
/*==================================================================*/


/*==================================================================*/
/*the function prints the results to the file*/
/*she gets the buffer to print and the name and location of the output file*/
/*the function returns 0 when done*/
int print_to_file(int print_to_file_buff[], char output_file[])
{
	int i = 0;
	FILE *f_mem = fopen(output_file, "w");//file to write
	if (f_mem == NULL)//check if file opened
	{
		printf("Error opening file!\n");
	}

	/*printing the buffer with all data, need to change not 500. every full command take a plce of 6 cells in the buffer*/
					/*printing each field with exactly number of hex digits as gadi said*/
	for (i = 0; i <= 6 * MAX_FILE_LENGTH - 1; i = i + 6)
	{		//remeber: the vALUES OF print_to_file_buff are integers
		fprintf(f_mem, "%01X", print_to_file_buff[i]);//op_code//%01x PRINT as 1 digit hexs
		fprintf(f_mem, "%01X", print_to_file_buff[i + 1]);
		fprintf(f_mem, "%01X", print_to_file_buff[i + 2]);
		fprintf(f_mem, "%01X", print_to_file_buff[i + 3]);
		fprintf(f_mem, "%01X", print_to_file_buff[i + 4]);
		if (print_to_file_buff[i + 5] < 0)//check if imm is a negative number - can be changed to masking without if
		{
			print_to_file_buff[i + 5] = print_to_file_buff[i + 5] & 0xFFF;//masking to cancle sign extantion
			fprintf(f_mem, "%03X", print_to_file_buff[i + 5]);//immidiate
		}
		else
		{
			fprintf(f_mem, "%03X", print_to_file_buff[i + 5]);//immidiate
		}

		fprintf(f_mem, "\n");
	}
	fclose(f_mem);//close the mem_out file
	return(0);
}
/*==================================================================*/


/*converts str to lower case only*/
/*the function gets string and retuns 0 when done*/
int strtolowercase(char str[])
{
	int i = 0;
	for (i = 0;i <= MAX_LINE_LENGTH;i++)
	{
		str[i] = tolower(str[i]);
	}
	return(0);
}