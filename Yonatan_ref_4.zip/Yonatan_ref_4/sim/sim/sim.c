#define _CRT_SECURE_NO_WARNINGS

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <math.h>
#include <stdint.h>
#include <stdbool.h>//used for bool type

#define MEMORY_SIZE 4096

struct mem_cell {
	int opcode;
	int rd;
	int rs;
	int rt;
	int rm;
	int imm;
	unsigned int cmnd;//used to store the entire command at once
};

/////////////////////////////function declaration zone
void parse(FILE* fp, struct mem_cell* mem_ptr);//function intended to parse the memin.txt content into an easier to work with array
int sign_extend(int num);//function used to sign extend the imm field. it extends the bit in the 11th position to bits 31:12
void print2trace(FILE *trace_ptr, int PC, unsigned int cmnd, int regarr[]);//this function writes to the trace output file in the required format: PC INST R0 R1 ... R15
void print2files(FILE *memout_ptr, struct mem_cell memin[], FILE *regout_ptr, int regarr[], FILE *count_ptr, int cmnd_cnt);//this function is intended to write the other output files in the required format
void opcode_state_machine(int *PC_ptr, int *cmnd_cnt_ptr, struct mem_cell memin[], int regarr[], int trace_ptr);////this function simulates the SIMP processor operation. It does so using a switch case statement on the opcode field of the memin struct and 
//implements the different instructions accordingly. It is done running when reaching a "halt" command. More details in documentation.
///////////////////////////////function declaration zone


//main function of simulator. simulates the processor's actions based on a given input
int main(int argc, char *argv[]) {
	//variables definition zone~~~~~~~~~~~~~~~~~~~~~~~~~~~
	int PC = 0;//Program counter register.
	//initialized at address 0 at the beginning of the run
	int *PC_ptr = &PC;
	//range of values is between 0 and 4095
	int cmnd_cnt = 0;//a counter intended to calculate the number of commands done by the processor
	int *cmnd_cnt_ptr = &cmnd_cnt;
	//register defintion
	int regarr[16] = { 0 };
	//register defintion

	struct mem_cell memin[MEMORY_SIZE] = { 0 };//memin array with size 4096 used to store the memin.txt file contents. initialized to 0.
	struct mem_cell *memin_ptr = &memin[0];//pointer to the first cell in the memin struct
	//output files definitions
	FILE *memin_file_ptr = fopen(argv[1], "r");//memin.txt file pointer
	if (memin_file_ptr == NULL)
		printf("error reading memin.txt file");
	FILE *memout_ptr = fopen(argv[2], "w");//memout.txt file pointer
	if (memout_ptr == NULL)
		printf("error creating memout.txt file");
	FILE *regout_ptr = fopen(argv[3], "w");//regout.txt file pointer
	if (regout_ptr == NULL)
		printf("error creating regout.txt file");
	FILE *trace_ptr = fopen(argv[4], "w");//trace.txt file pointer
	if (trace_ptr == NULL)
		printf("error creating trace.txt file");
	FILE *count_ptr = fopen(argv[5], "w");//count.txt file pointer
	if (count_ptr == NULL)
		printf("error creating count.txt file");
	//variables definition zone~~~~~~~~~~~~~~~~~~~~~~~~~~~

	parse(memin_file_ptr, memin_ptr);//parse function call
	fclose(memin_file_ptr);
	opcode_state_machine(PC_ptr, cmnd_cnt_ptr, memin, regarr, trace_ptr);
	fclose(trace_ptr);

	/////////printing to memout.txt, regout.txt, count.txt//////////////////
	print2files(memout_ptr, memin, regout_ptr, regarr, count_ptr, cmnd_cnt);
	fclose(memout_ptr);
	fclose(regout_ptr);
	fclose(count_ptr);
	/////////printing to memout.txt, regout.txt, count.txt//////////////////
	return 0;
}

//this function parses the input memin text file into an array of type mem_cell which was defined above
//its inputs are a pointer to an input file and a pointer to the array of type mem_cell designated to contain the input text file's conetents
void parse(FILE* fp, struct mem_cell* mem_ptr) {
	char *ptr = NULL;//a char pointer. it is required to be used as an input argument for the strtol function used later
	int i = 0;
	int j = 0;
	char newline[10];//intended to store 8 bits of data, 9 including '/n' at the end of a row + '/0' at the end of the string
	char HI[5] = { '1', '1', '1', '1', '\0' };//dummy initialization
	char LO[5] = { '1', '1', '1', '1', '\0' };//dummy initialization
	int newline_dec_HI = 0;
	int newline_dec_LO = 0;
	while (fgets(newline, 10, fp) != NULL) {//8 hex digits (=32 bits) + 1 '\n' character are read from the memin.txt file. 9 total + 1 for the '\0' termination
		newline[8] = '\0';//place a '\0' after reading '\n' at the end of a line to terminate the string
		//now we parse the string read into newline into two registers for easier digestion by the strtol function up ahead. without this, strtol would return rubbish
		//data because an overflow would occur
		for (j = 7; j > 3; j--)
			LO[j - 4] = newline[j];
		for (j = 3; j >= 0; j--)
			HI[j] = newline[j];
		//strtol converts the strings stored in HI and LO to decimal values.
		//these values are then used to correctly fill the registers of each address in the memory cell
		newline_dec_HI = (int)strtol(HI, &ptr, 16);//4 hex digits = 16 bit
		mem_ptr[i].opcode = (newline_dec_HI & 0xF000) >> 12;
		mem_ptr[i].rd = (newline_dec_HI & 0x0F00) >> 8;
		mem_ptr[i].rs = (newline_dec_HI & 0x00F0) >> 4;
		mem_ptr[i].rt = (newline_dec_HI & 0x000F);
		newline_dec_LO = (int)strtol(LO, &ptr, 16);//4 hex digits = 16 bit
		mem_ptr[i].rm = (newline_dec_LO & 0xF000) >> 12;
		mem_ptr[i].imm = newline_dec_LO & 0x0FFF;

		mem_ptr[i].cmnd = ((unsigned int)newline_dec_HI) << 16;//shift left by 16 bits
		mem_ptr[i].cmnd = mem_ptr[i].cmnd | ((unsigned int)newline_dec_LO);//logical OR to store the lower 16 bits

		i++;
	};
}

//this function expects to get as argument the imm field value (12 bits number) and extends its sign bit to bits 12 to 31
int sign_extend(int num) {
	int i = 0;
	int extended_num = 0;
	int sgn = (num & 0b100000000000) >> 11;//get the sign bit
	for (i = 0; i < 20; i++) {//create 20 bits all equal to the sign bit
		extended_num = (extended_num | sgn);
		if (i + 1 != 20)
			extended_num = extended_num << 1;
	};
	extended_num = extended_num << 12;
	extended_num = extended_num | num;//extended num now contains the input value extended to 32 bits
	return extended_num;
}

//this function writes to the trace output file in the required format: PC INST R0 R1 ... R15
void print2trace(FILE *trace_ptr, int PC, unsigned int cmnd, int regarr[]) {
	char trace_buffer[8 * 18 + 17 + 1 + 1] = { '\0' };//18 fields, each with 8 characters, 17 spaces between them, +1 for '\n', +1 for '\0'
	sprintf(trace_buffer, "%08X %08X %08X %08X %08X %08X %08X %08X %08X %08X %08X %08X %08X %08X %08X %08X %08X %08X\n",
		PC, cmnd, regarr[0], regarr[1], regarr[2], regarr[3], regarr[4], regarr[5], regarr[6], regarr[7], regarr[8], regarr[9],
		regarr[10], regarr[11], regarr[12], regarr[13], regarr[14], regarr[15]);
	fputs(trace_buffer, trace_ptr);//consider writing an fprintf version
}

//this function writes to the other output files (memout.txt, regout.txt, count.txt) in the required format
void print2files(FILE *memout_ptr, struct mem_cell memin[], FILE *regout_ptr, int regarr[], FILE *count_ptr, int cmnd_cnt) {
	int i = 0;
	//memout.txt printing
	for (i = 0; i < MEMORY_SIZE; i++) {
		fprintf(memout_ptr, "%08X\n", memin[i].cmnd);
	}

	//regout.txt printing
	for (i = 0; i < 16; i++) {
		fprintf(regout_ptr, "%08X\n", regarr[i]);
	}

	//count.txt printing
	fprintf(count_ptr, "%d\n", cmnd_cnt);
}

//this function simulates the SIMP processor operation. It does so using a switch case statement on the opcode field of the memin struct and 
//implements the different instructions accordingly. It is done running when reaching a "halt" command.
void opcode_state_machine(int *PC_ptr, int *cmnd_cnt_ptr, struct mem_cell memin[], int regarr[], int trace_ptr) {
	bool halt_flag = false;//flag for when reaching a halt command
	int sra_sgn = 0;//sign bit of the rs register for the sra command
	int sra_num_of_shifts = 0;//amount of times needed to shift right the rs register is stored here
	int sra_sgn_chain = 0;//a chain of bits all equal to the sign bit of rs register for sra command.
	int aux_address = 0;//auxiliary variable for address calculation in sw command

	while (halt_flag == false)
	{
		switch (memin[*PC_ptr].opcode) {
		case 0://add command
			//R[rd] = R[rs] + R[rt] + simm
			print2trace(trace_ptr, *PC_ptr, memin[*PC_ptr].cmnd, regarr);//we send the registers array before the memory map has been changed
			//ie before the command has been executed
			regarr[memin[*PC_ptr].rd] = regarr[memin[*PC_ptr].rs] + regarr[memin[*PC_ptr].rt] + sign_extend(memin[*PC_ptr].imm);
			(*PC_ptr)++;
			(*cmnd_cnt_ptr)++;
			break;

		case 1://sub command
			//R[rd] = R[rs] � R[rt] � simm
			print2trace(trace_ptr, (*PC_ptr), memin[*PC_ptr].cmnd, regarr);//we send the registers array before the memory map has been changed
			//ie before the command has been executed
			regarr[memin[*PC_ptr].rd] = regarr[memin[*PC_ptr].rs] - regarr[memin[*PC_ptr].rt] - sign_extend(memin[*PC_ptr].imm);
			(*PC_ptr)++;
			(*cmnd_cnt_ptr)++;
			break;

		case 2://and command
			//R[rd] = R[rs] & R[rt] & simm
			print2trace(trace_ptr, *PC_ptr, memin[*PC_ptr].cmnd, regarr);//we send the registers array before the memory map has been changed
			//ie before the command has been executed
			regarr[memin[*PC_ptr].rd] = regarr[memin[*PC_ptr].rs] & regarr[memin[*PC_ptr].rt] & sign_extend(memin[*PC_ptr].imm);
			(*PC_ptr)++;
			(*cmnd_cnt_ptr)++;
			break;

		case 3://or command
			//R[rd] = R[rs] | R[rt] | simm
			print2trace(trace_ptr, *PC_ptr, memin[*PC_ptr].cmnd, regarr);//we send the registers array before the memory map has been changed
			//ie before the command has been executed
			regarr[memin[*PC_ptr].rd] = regarr[memin[*PC_ptr].rs] | regarr[memin[*PC_ptr].rt] | sign_extend(memin[*PC_ptr].imm);
			(*PC_ptr)++;
			(*cmnd_cnt_ptr)++;
			break;

		case 4://sll command
			//R[rd] = R[rs] << [R[rt] + imm]
			print2trace(trace_ptr, *PC_ptr, memin[*PC_ptr].cmnd, regarr);//we send the registers array before the memory map has been changed
			//ie before the command has been executed
			regarr[memin[*PC_ptr].rd] = regarr[memin[*PC_ptr].rs] << (regarr[memin[*PC_ptr].rt] + memin[*PC_ptr].imm);
			(*PC_ptr)++;
			(*cmnd_cnt_ptr)++;
			break;

		case 5://sra command
			//R[rd] = R[rs] >> [R[rt] + imm] 
			//arithmetic shift with sign extension
			print2trace(trace_ptr, *PC_ptr, memin[*PC_ptr].cmnd, regarr);//we send the registers array before the memory map has been changed
			//ie before the command has been executed

			//read the explanation below for better understanding the next steps
			sra_sgn = (regarr[memin[*PC_ptr].rs] & 0b10000000000000000000000000000000) >> 31;//get the sign bit of the R[rs] register

			if (sra_sgn == 1) {
				sra_num_of_shifts = (regarr[memin[*PC_ptr].rt] + memin[*PC_ptr].imm);//auxiliary variable storing the number of places shifting right will occur
				for (; sra_num_of_shifts > 0; sra_num_of_shifts--) {//create a string of #(sra_num_of_shifts) bits all equal to the sign bit
					sra_sgn_chain = (sra_sgn_chain | sra_sgn);
					if (sra_num_of_shifts - 1 != 0)
						sra_sgn_chain = sra_sgn_chain << 1;
				}

				sra_num_of_shifts = (regarr[memin[*PC_ptr].rt] + memin[*PC_ptr].imm);
				sra_sgn_chain = sra_sgn_chain << (32 - sra_num_of_shifts);//now sra_sgn_chain contains the required 32 bits that will be logically OR'd with the destination register
				regarr[memin[*PC_ptr].rd] = regarr[memin[*PC_ptr].rs] >> (regarr[memin[*PC_ptr].rt] + memin[*PC_ptr].imm);
				regarr[memin[*PC_ptr].rd] = regarr[memin[*PC_ptr].rd] | sra_sgn_chain;
			}

			else
				regarr[memin[*PC_ptr].rd] = regarr[memin[*PC_ptr].rs] >> (regarr[memin[*PC_ptr].rt] + memin[*PC_ptr].imm);
			//explanation: let's take an example. if R[rd] = 0b 1011 0010 1010 1011 1111 0000 0000 1001
			//and the amount of shifts to the right (aka [R[rt] + imm]) is equal to 3, we create a chain of 32 bits stored in sra_sgn_chain,
			//where the first 3 bits are equal to 1 (the sign bit), and the other 29 bits (aka (32 - sra_num_of_shifts)) are equal to 0.
			//now sra_sgn_chain will contain the following bits: 0b 1110 0000 0000 0000 0000 0000 0000 0000
			//then, after a logical right shift of 3 places done on the destination register, we do a bitwise OR between 
			//sra_sgn_chain and the destination register, and we get the desired output,
			//ie the destination register is equal to 0b 1111 0110 0101 0101 0111 1110 0000 0001
			//in  case the sign bit is equal to 0, no sign extension is required and the destination register is simply shited right the required amount of times

			(*PC_ptr)++;
			(*cmnd_cnt_ptr)++;
			break;

		case 6://mac command
			//R[rd] = R[rs] * R[rt] + R[rm] + simm
			print2trace(trace_ptr, *PC_ptr, memin[*PC_ptr].cmnd, regarr);//we send the registers array before the memory map has been changed
			//ie before the command has been executed
			regarr[memin[*PC_ptr].rd] = regarr[memin[*PC_ptr].rs] * regarr[memin[*PC_ptr].rt] + regarr[memin[*PC_ptr].rm] + sign_extend(memin[*PC_ptr].imm);
			(*PC_ptr)++;
			(*cmnd_cnt_ptr)++;
			break;

		case 7://branch command
			//if ((rm == 0) && (R[rs] == R[rt])) pc = imm
			//if ((rm == 1) && (R[rs] != R[rt])) pc = imm
			//if ((rm == 2) && (R[rs] > R[rt])) pc = imm
			//if ((rm == 3) && (R[rs] < R[rt])) pc = imm
			//if ((rm == 4) && (R[rs] >= R[rt])) pc = imm
			//if ((rm == 5) && (R[rs] <= R[rt])) pc = imm
			print2trace(trace_ptr, *PC_ptr, memin[*PC_ptr].cmnd, regarr);//we send the registers array before the memory map has been changed
			//ie before the command has been executed

			(*cmnd_cnt_ptr)++;

			if ((memin[*PC_ptr].rm == 0) && (regarr[memin[*PC_ptr].rs] == regarr[memin[*PC_ptr].rt]))
				*PC_ptr = memin[*PC_ptr].imm;

			else if ((memin[*PC_ptr].rm == 1) && (regarr[memin[*PC_ptr].rs] != regarr[memin[*PC_ptr].rt]))
				*PC_ptr = memin[*PC_ptr].imm;

			else if ((memin[*PC_ptr].rm == 2) && (regarr[memin[*PC_ptr].rs] > regarr[memin[*PC_ptr].rt]))
				*PC_ptr = memin[*PC_ptr].imm;

			else if ((memin[*PC_ptr].rm == 3) && (regarr[memin[*PC_ptr].rs] < regarr[memin[*PC_ptr].rt]))
				*PC_ptr = memin[*PC_ptr].imm;

			else if ((memin[*PC_ptr].rm == 4) && (regarr[memin[*PC_ptr].rs] >= regarr[memin[*PC_ptr].rt]))
				*PC_ptr = memin[*PC_ptr].imm;

			else if ((memin[*PC_ptr].rm == 5) && (regarr[memin[*PC_ptr].rs] <= regarr[memin[*PC_ptr].rt]))
				*PC_ptr = memin[*PC_ptr].imm;
			else
				(*PC_ptr)++;

			break;

		case 8://reserved command
			break;

		case 9://reserved command
			break;

		case 10://reserved command
			break;

		case 11://jal command
			//R[15] = (pc + 1) & 0xfff (next instruction address), pc = imm
			print2trace(trace_ptr, *PC_ptr, memin[*PC_ptr].cmnd, regarr);//we send the registers array before the memory map has been changed
			//ie before the command has been executed
			regarr[15] = ((*PC_ptr) + 1) & 0xfff;
			(*PC_ptr) = memin[*PC_ptr].imm;
			(*cmnd_cnt_ptr)++;
			break;

		case 12://lw command
			//R[rd] = MEM[(R[rs]+simm) & 0xfff]
			//this is a 32 bit word to load into R[rd]
			print2trace(trace_ptr, *PC_ptr, memin[*PC_ptr].cmnd, regarr);//we send the registers array before the memory map has been changed
			//ie before the command has been executed
			regarr[memin[*PC_ptr].rd] = memin[(regarr[memin[*PC_ptr].rs] + sign_extend(memin[*PC_ptr].imm)) & 0xfff].cmnd;
			(*PC_ptr)++;
			(*cmnd_cnt_ptr)++;
			break;

		case 13://sw command
			//MEM[(R[rs]+simm) & 0xfff] = R[rd]
			//this is a 32 bit word to store inside the memory
			print2trace(trace_ptr, *PC_ptr, memin[*PC_ptr].cmnd, regarr);//we send the registers array before the memory map has been changed
			//ie before the command has been executed
			aux_address = (regarr[memin[*PC_ptr].rs] + sign_extend(memin[*PC_ptr].imm)) & 0xfff;//calculating the required address for easier code readability
			memin[aux_address].cmnd = regarr[memin[*PC_ptr].rd];//loading the word into the appropriate address
			//updating the rest of the fields in the appropriate address accordingly
			memin[aux_address].opcode = (memin[aux_address].cmnd & 0xf0000000) >> 28;
			memin[aux_address].rd = (memin[aux_address].cmnd & 0x0f000000) >> 24;
			memin[aux_address].rs = (memin[aux_address].cmnd & 0x00f00000) >> 20;
			memin[aux_address].rt = (memin[aux_address].cmnd & 0x000f0000) >> 16;
			memin[aux_address].rm = (memin[aux_address].cmnd & 0x0000f000) >> 12;
			memin[aux_address].imm = (memin[aux_address].cmnd & 0x00000fff);
			//updating the rest of the fields in the appropriate address accordingly
			(*PC_ptr)++;
			(*cmnd_cnt_ptr)++;
			break;

		case 14://jr command
			//pc = R[rd] & 0xfff
			print2trace(trace_ptr, *PC_ptr, memin[*PC_ptr].cmnd, regarr);//we send the registers array before the memory map has been changed
			//ie before the command has been executed
			(*PC_ptr) = regarr[memin[*PC_ptr].rd] & 0xff;
			(*cmnd_cnt_ptr)++;
			break;

		case 15://halt command
			//Halt execution, exit simulator
			print2trace(trace_ptr, *PC_ptr, memin[*PC_ptr].cmnd, regarr);//we send the registers array before the memory map has been changed
			//ie before the command has been executed
			(*cmnd_cnt_ptr)++;
			halt_flag = true;
			break;
		}
	}
}