#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#define MAX_ROW_LENGTH 40
#define MEM_SIZE 4096
#define TRUE 1
#define FALSE 0

#pragma warning(disable:4996)

//==================== Structures ======================//
typedef struct Memory				//Define of Memory structure (A Representation of Command/Imm Line)
{
	char mem[5];					//Content of Memory
	int active;						//Tells if the Memory line is in use or not (helps for filling zeros)
} Memory;

//=========== Global Variables Initiallize =============//
int pc = 0;							//Initiallizing PC of the Simulator
char r0[5] = "0000\0";				//Initiallizing Register $zero
char r1[5] = "0000\0";				//Initiallizing Register $at
char r2[5] = "0000\0";				//Initiallizing Register $v0
char r3[5] = "0000\0";				//Initiallizing Register $a0
char r4[5] = "0000\0";				//Initiallizing Register $a1
char r5[5] = "0000\0";				//Initiallizing Register $t0
char r6[5] = "0000\0";				//Initiallizing Register $t1
char r7[5] = "0000\0";				//Initiallizing Register $t2
char r8[5] = "0000\0";				//Initiallizing Register $t3
char r9[5] = "0000\0";				//Initiallizing Register $s0
char r10[5] = "0000\0";				//Initiallizing Register $s1
char r11[5] = "0000\0";				//Initiallizing Register $s2
char r12[5] = "0000\0";				//Initiallizing Register $gp
char r13[5] = "0000\0";				//Initiallizing Register $fp
char r14[5] = "0000\0";				//Initiallizing Register $sp
char r15[5] = "0000\0";				//Initiallizing Register $ra
char *regArray[16] = { r0,r1,r2,r3,r4,r5,r6,r7,r8,r9,r10,r11,r12,r13,r14,r15 }; //Initiallizing Registers Array
Memory memList[MEM_SIZE];			//Initiallizing the Memory Array for easy access to the Memory
int counter = 0;					//Initiallizing Command Execution Counter
int halt = FALSE;					//Initiallizing a Halt Flag

//============= Base Convert Functions ==============//

//This Function get a hexadecimal base bit (char) and return a decimal base value (int)
int hexBit2Dec(char hexBit)
{
	if (hexBit == '0') return 0;
	if (hexBit == '1') return 1;
	if (hexBit == '2') return 2;
	if (hexBit == '3') return 3;
	if (hexBit == '4') return 4;
	if (hexBit == '5') return 5;
	if (hexBit == '6') return 6;
	if (hexBit == '7') return 7;
	if (hexBit == '8') return 8;
	if (hexBit == '9') return 9;
	if (hexBit == 'A') return 10;
	if (hexBit == 'B') return 11;
	if (hexBit == 'C') return 12;
	if (hexBit == 'D') return 13;
	if (hexBit == 'E') return 14;
	if (hexBit == 'F') return 15;
}

//This Function get a hexadecimal base bit (char) and return a 4-bit binary base value (*char)
char *hexBit2Bin(char hexBit)
{
	char binStr[5];
	if (hexBit == '0') return "0000\0";
	if (hexBit == '1') return "0001\0";
	if (hexBit == '2') return "0010\0";
	if (hexBit == '3') return "0011\0";
	if (hexBit == '4') return "0100\0";
	if (hexBit == '5') return "0101\0";
	if (hexBit == '6') return "0110\0";
	if (hexBit == '7') return "0111\0";
	if (hexBit == '8') return "1000\0";
	if (hexBit == '9') return "1001\0";
	if (hexBit == 'A') return "1010\0";
	if (hexBit == 'B') return "1011\0";
	if (hexBit == 'C') return "1100\0";
	if (hexBit == 'D') return "1101\0";
	if (hexBit == 'E') return "1110\0";
	if (hexBit == 'F') return "1111\0";
}

//This Function get a 16-bit binary base value (*char) and return a decimal base value (int)
char *hexWord2Bin(char *hexWord)
{
	char binWord[17];
	char bit0 = hexWord[0];
	char bit1 = hexWord[1];
	char bit2 = hexWord[2];
	char bit3 = hexWord[3];
	if (hexWord[1] == '\0')
	{
		bit3 = hexWord[0];
		bit2 = '0';
		bit1 = '0';
		bit0 = '0';
	}
	else if (hexWord[2] == '\0')
	{
		bit3 = hexWord[1];
		bit2 = hexWord[0];
		bit1 = '0';
		bit0 = '0';
	}
	else if (hexWord[3] == '\0')
	{
		bit3 = hexWord[2];
		bit2 = hexWord[1];
		bit1 = hexWord[0];
		bit0 = '0';
	}
	strcpy(&binWord[0], hexBit2Bin(bit0));
	strcpy(&binWord[4], hexBit2Bin(bit1));
	strcpy(&binWord[8], hexBit2Bin(bit2));
	strcpy(&binWord[12], hexBit2Bin(bit3));
	binWord[16] = '\0';
	return binWord;
}

//This Function get a 16-bit binary base value (*char) and return a decimal base value (int)
int bin2Dec(char *binWord)
{
	int dec = 0;
	for (int i = 0; i < 16; i++)
	{
		int bit = 0;
		if (binWord[15 - i] == '1')bit = 1;
		dec += ((bit)*(pow(2, i)));

	}
	if (dec > 32767)
	{
		dec = (-65536 + dec);
	}
	return dec;
}

//This Function get a 4-bit hexadecimal base value (*char) and return a decimal base value (int)
int hexWord2Dec(char *hexWord)
{
	char binWord[17];
	int decNum;
	strcpy(binWord, hexWord2Bin(hexWord));
	decNum = bin2Dec(binWord);
	return decNum;
}

//This Function get a decimal base value (int) and return a hexadecimal base value (*char)
char *dec2Hex(int dec)
{
	if (dec < 0) dec = 65536 + dec;
	int i = 0, j, temp;
	char hex[5];
	while (dec != 0) {
		temp = dec % 16;
		if (temp < 10)
			temp = temp + 48; else
			temp = temp + 55;
		hex[i++] = temp;
		dec = dec / 16;
	}
	while (i < 4)
	{
		hex[i] = '0';
		i++;
	}

	hex[4] = '\0';
	strrev(hex);
	hex[4] = '\0';
	return hex;
}

//============ Bits Aritmetics Functions ============//

//This Function get two bits and return a bit (bit1 and bit2)
char bitAnd(char bit1, char bit2)
{
	if (bit1 == '1' && bit2 == '1') return '1';
	return '0';
}

//This Function get two bits and return a bit (bit1 or bit2)
char bitOr(char bit1, char bit2)
{
	if (bit1 == '1' || bit2 == '1') return '1';
	return '0';
}

//========= Aritmetics Operation Commands ===========//

//This Function get two 4-bit hex values and return a 4-bit hex value (reg1 + reg2)
char *addOp(char *reg1, char *reg2)
{
	char hexResult[5];
	int reg1Dec = hexWord2Dec(reg1);
	int reg2Dec = hexWord2Dec(reg2);
	int decResult = reg1Dec + reg2Dec;
	strcpy(hexResult, dec2Hex(decResult));
	return hexResult;
}

//This Function get two 4-bit hex values and return a 4-bit hex value (reg1 - reg2)
char *subOp(char *reg1, char *reg2)
{
	char hexResult[5];
	int reg1Dec = hexWord2Dec(reg1);
	int reg2Dec = hexWord2Dec(reg2);
	int decResult = reg1Dec - reg2Dec;
	strcpy(hexResult, dec2Hex(decResult));
	return hexResult;
}

//This Function get two 4-bit hex values and return a 4-bit hex value (reg1 * reg2)
char *mulOp(char *reg1, char *reg2)
{
	char hexResult[5];
	int reg1Dec = hexWord2Dec(reg1);
	int reg2Dec = hexWord2Dec(reg2);
	int decResult = reg1Dec * reg2Dec;
	strcpy(hexResult, dec2Hex(decResult));
	return hexResult;
}

//This Function get two 4-bit hex values and return a 4-bit hex value (reg1 and reg2)
char *andOp(char *reg1, char *reg2)
{
	char binWord1[17];
	char binWord2[17];
	char binResult[17];
	char hexResult[5];
	strcpy(binWord1, hexWord2Bin(reg1));
	strcpy(binWord2, hexWord2Bin(reg2));

	binWord1[16] = '\0';
	binWord2[16] = '\0';
	for (int i = 0; i < 16; i++)
	{
		binResult[i] = bitAnd(binWord1[i], binWord2[i]);
	}
	binResult[16] = '\0';
	strcpy(hexResult, dec2Hex(bin2Dec(binResult)));
	return hexResult;

}

//This Function get two 4-bit hex values and return a 4-bit hex value (reg1 or reg2)
char *orOp(char *reg1, char *reg2)
{
	char binWord1[17];
	char binWord2[17];
	char binResult[17];
	char hexResult[5];
	strcpy(binWord1, hexWord2Bin(reg1));
	strcpy(binWord2, hexWord2Bin(reg2));

	binWord1[16] = '\0';
	binWord2[16] = '\0';
	for (int i = 0; i < 16; i++)
	{
		binResult[i] = bitOr(binWord1[i], binWord2[i]);
	}
	binResult[16] = '\0';
	strcpy(hexResult, dec2Hex(bin2Dec(binResult)));
	return hexResult;

}

//This Function get two 4-bit hex values and return a 4-bit Left Logic Shifted hex value (reg1<<reg2)
char *sllOp(char *reg1, char *reg2)
{
	char hexResult[5];
	char reg1Bin[17];
	int reg2Dec = hexWord2Dec(reg2);
	strcpy(reg1Bin, hexWord2Bin(reg1));
	for (int i = 0; i < reg2Dec; i++)
	{
		for (int j = 0; j < 15; j++)
		{
			reg1Bin[j] = reg1Bin[j + 1];
		}
		reg1Bin[15] = '0';
	}
	strcpy(hexResult, dec2Hex(bin2Dec(reg1Bin)));
	return hexResult;
}

//This Function get two 4-bit hex values and return a 4-bit Right Aritemtic Shifted hex value (reg1>>reg2)
char *sraOp(char *reg1, char *reg2)
{
	char hexResult[5];
	char reg1Bin[17];
	int reg2Dec = hexWord2Dec(reg2);
	strcpy(reg1Bin, hexWord2Bin(reg1));

	for (int i = 0; i < reg2Dec; i++)
	{
		for (int j = 0; j < 15; j++)
		{
			reg1Bin[15 - j] = reg1Bin[15 - (j + 1)];
		}
		reg1Bin[0] = reg1Bin[1];
	}
	strcpy(hexResult, dec2Hex(bin2Dec(reg1Bin)));
	return hexResult;
}

//========= Command Execution Functions ==========//

//This Function get a command and execute it
void executeCommand(char *cmd)
{
	pc++;
	counter++;
	char op = cmd[0];
	char rd = cmd[1];
	char rs = cmd[2];
	char rt = cmd[3];
	char result[5];
	if (op == '0') strcpy(result, addOp(regArray[hexBit2Dec(rs)], regArray[hexBit2Dec(rt)]));
	if (op == '1') strcpy(result, subOp(regArray[hexBit2Dec(rs)], regArray[hexBit2Dec(rt)]));
	if (op == '2') strcpy(result, mulOp(regArray[hexBit2Dec(rs)], regArray[hexBit2Dec(rt)]));
	if (op == '3') strcpy(result, andOp(regArray[hexBit2Dec(rs)], regArray[hexBit2Dec(rt)]));
	if (op == '4') strcpy(result, orOp(regArray[hexBit2Dec(rs)], regArray[hexBit2Dec(rt)]));
	if (op == '5') strcpy(result, sllOp(regArray[hexBit2Dec(rs)], regArray[hexBit2Dec(rt)]));
	if (op == '6') strcpy(result, sraOp(regArray[hexBit2Dec(rs)], regArray[hexBit2Dec(rt)]));
	if (op == '8' && rd == '6')
	{
		pc = hexWord2Dec(regArray[hexBit2Dec(rs)]);
		return;
	}
	if (op == 'F')
	{
		halt = TRUE;
		return;
	}
	strcpy(regArray[hexBit2Dec(rd)], result);

}

//This Function get a command and imm and execute it
void executeImmCommand(char *cmd, char *imm)
{
	pc = pc + 2;
	counter++;
	char op = cmd[0];
	char rd = cmd[1];
	char rs = cmd[2];
	char rt = cmd[3];
	char result[5];
	if (op == '7') strcpy(regArray[hexBit2Dec(rd)], imm);
	if (op == '8' && rd == '0')
	{
		if (hexWord2Dec(regArray[hexBit2Dec(rs)]) == hexWord2Dec(regArray[hexBit2Dec(rt)])) pc = hexWord2Dec(imm);
	}
	if (op == '8' && rd == '1')
	{
		if (hexWord2Dec(regArray[hexBit2Dec(rs)]) != hexWord2Dec(regArray[hexBit2Dec(rt)])) pc = hexWord2Dec(imm);
	}
	if (op == '8' && rd == '2')
	{
		if (hexWord2Dec(regArray[hexBit2Dec(rs)]) > hexWord2Dec(regArray[hexBit2Dec(rt)])) pc = hexWord2Dec(imm);
	}
	if (op == '8' && rd == '3')
	{
		if (hexWord2Dec(regArray[hexBit2Dec(rs)]) < hexWord2Dec(regArray[hexBit2Dec(rt)])) pc = hexWord2Dec(imm);
	}
	if (op == '8' && rd == '4')
	{
		if (hexWord2Dec(regArray[hexBit2Dec(rs)]) >= hexWord2Dec(regArray[hexBit2Dec(rt)])) pc = hexWord2Dec(imm);
	}
	if (op == '8' && rd == '5')
	{
		if (hexWord2Dec(regArray[hexBit2Dec(rs)]) <= hexWord2Dec(regArray[hexBit2Dec(rt)])) pc = hexWord2Dec(imm);
	}
	if (op == '9')
	{
		strcpy(regArray[15], dec2Hex(pc));
		pc = hexWord2Dec(imm);
	}
	if (op == 'A')
	{
		strcpy(regArray[hexBit2Dec(rd)], memList[hexWord2Dec(regArray[hexBit2Dec(rs)]) + hexWord2Dec(imm)].mem);
	}
	if (op == 'B')
	{
		strcpy(memList[hexWord2Dec(regArray[hexBit2Dec(rs)]) + hexWord2Dec(imm)].mem, regArray[hexBit2Dec(rd)]);
		memList[hexWord2Dec(regArray[hexBit2Dec(rs)]) + hexWord2Dec(imm)].active = TRUE;
	}
}

/*=========== File Writting Functions ============*/

//This Function writes the PC,Command and Registers Values before each operation is being Execute to the trace file
void writeTrace(FILE *trace, char *cmd)
{
	char hexPc[5];
	strcpy(hexPc, dec2Hex(pc));
	//	printf("%s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s\n", hexPc, cmd, r0, r1, r2, r3, r4, r5, r6, r7, r8, r9, r10, r11, r12, r13, r14, r15);

	fprintf(trace, "%s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s\n", hexPc, cmd, r0, r1, r2, r3, r4, r5, r6, r7, r8, r9, r10, r11, r12, r13, r14, r15);
}
//This Function writes the Register values at the end of the program to the regout file
void writeRegout(FILE *regout, char *regArray)
{
	fprintf(regout, "%s\n%s\n%s\n%s\n%s\n%s\n%s\n%s\n%s\n%s\n%s\n%s\n%s\n%s\n%s\n%s\n", r0, r1, r2, r3, r4, r5, r6, r7, r8, r9, r10, r11, r12, r13, r14, r15);
}
//This Function writes the Number of executed operations at the end of the program to the count file
void writeCount(FILE *count, int counter)
{
	fprintf(count, "%d", counter);
}
//This Function writes the Memory image at the end of the program to the memout file
void writeMemout(FILE *memout)
{
	int lastMemIndex = 0;
	for (int i = 0; i < MEM_SIZE; i++)
	{
		if (memList[i].active == TRUE) lastMemIndex = i;
	}

	for (int i = 0; i <= lastMemIndex; i++)
	{
		if (memList[i].active != TRUE)
		{
			Memory emptyMem = { "0000\0",TRUE };
			memList[i] = emptyMem;
		}
	}
	for (int i = 0; i <= lastMemIndex; i++)
	{
		fprintf(memout, "%s\n", memList[i].mem);
	}
}

/*============= Conditions Functions =============*/

//This Function checks if the command given is an Imm command (TRUE) or not (FALSE)
int isImmCommand(char op, char rd)
{
	if (op == '7' || op == '9' || op == 'A' || op == 'B') return TRUE;
	if (op == '8' && rd != '6') return TRUE;
	return FALSE;
}

/*=========== File Handeling Functions ===========*/

//This Function checks if enough arguments were given to the program
void checkArgs(int argc)
{
	if (argc != 6)
	{
		printf("Error: %d File(s) of 5 were missing!", 5 - (argc - 1));
		printf("\nPress any key to countinue...");
		getchar();
		exit(1);
	}
}
//This Function gets a File and checks if it was opened correctly
void checkFile(FILE *file, char *name)
{
	if (file == NULL)
	{
		printf("Error: There was a problem opening %s!", name);
		printf("\nPress any key to countinue...");
		getchar();
		exit(1);
	}
}

int main(int argc, char* argv[])
{
	//========= Input Verification & Handeling ==========//
	checkArgs(argc);														//Check if enough files were loaded
	FILE *memin = NULL, *memout = NULL, *regout = NULL, *trace = NULL, *count = NULL;		//Create file Pointers
	memin = fopen(argv[1], "r");
	memout = fopen(argv[2], "w");
	regout = fopen(argv[3], "w");
	trace = fopen(argv[4], "w");
	count = fopen(argv[5], "w");
	checkFile(memin, argv[1]);
	checkFile(memout, argv[2]);
	checkFile(regout, argv[3]);
	checkFile(trace, argv[4]);
	checkFile(count, argv[5]);

	//=============== Variables Initiallize ================//
	int memIndex = 0;
	char line[MAX_ROW_LENGTH];

	//=============== Variables Initiallize ================//
	while (!feof(memin))
	{
		fgets(line, MAX_ROW_LENGTH, memin);
		line[4] = '\0';
		strcpy(memList[memIndex].mem, line);
		memList[memIndex].active = TRUE;
		memIndex++;


	}
	memList[memIndex - 1].active = FALSE;
	while (halt == FALSE)
	{
		writeTrace(trace, memList[pc].mem);
		if (isImmCommand(memList[pc].mem[0], memList[pc].mem[1]) == TRUE)
		{
			executeImmCommand(memList[pc].mem, memList[pc + 1].mem);
		}
		else executeCommand(memList[pc].mem);
	}
	writeRegout(regout, regArray);
	writeCount(count, counter);
	writeMemout(memout);

	fclose(memin);
	fclose(memout);
	fclose(regout);
	fclose(count);
	fclose(trace);

	return 0;
}