#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#define MAX_ROW_LENGTH 501
#define MAX_LABEL_LENGTH 50
#define MEM_SIZE 4096
#define TRUE 1
#define FALSE 0

#pragma warning(disable:4996)

//==================== Structures ======================//
typedef struct Label
{
	char name[MAX_LABEL_LENGTH];
	int pc;

} Label;
typedef struct Memory				//Define of Memory structure (A Representation of Command/Imm Line)
{
	char mem[5];					//Content of Memory
	int active;						//Tells if the Memory line is in use or not (helps for filling zeros)
} Memory;

//============= Base Convert Functions ==============//

//This Function get a hexadecimal base bit (char) and return a 4-bit binary base value (*char)
char *hexBit2Bin(char hexBit)
{
	char binStr[5];
	if (hexBit == '0') return "0000\0";
	if (hexBit == '1') return "0001\0";
	if (hexBit == '2') return "0010\0";
	if (hexBit == '3') return "0011\0";
	if (hexBit == '4') return "0100\0";
	if (hexBit == '5') return "0101\0";
	if (hexBit == '6') return "0110\0";
	if (hexBit == '7') return "0111\0";
	if (hexBit == '8') return "1000\0";
	if (hexBit == '9') return "1001\0";
	if (hexBit == 'A') return "1010\0";
	if (hexBit == 'B') return "1011\0";
	if (hexBit == 'C') return "1100\0";
	if (hexBit == 'D') return "1101\0";
	if (hexBit == 'E') return "1110\0";
	if (hexBit == 'F') return "1111\0";
}

//This Function get a 16-bit binary base value (*char) and return a decimal base value (int)
char *hexWord2Bin(char *hexWord)
{
	char binWord[17];
	char bit0 = hexWord[0];
	char bit1 = hexWord[1];
	char bit2 = hexWord[2];
	char bit3 = hexWord[3];
	if (hexWord[1] == '\0')
	{
		bit3 = hexWord[0];
		bit2 = '0';
		bit1 = '0';
		bit0 = '0';
	}
	else if (hexWord[2] == '\0')
	{
		bit3 = hexWord[1];
		bit2 = hexWord[0];
		bit1 = '0';
		bit0 = '0';
	}
	else if (hexWord[3] == '\0')
	{
		bit3 = hexWord[2];
		bit2 = hexWord[1];
		bit1 = hexWord[0];
		bit0 = '0';
	}
	strcpy(&binWord[0], hexBit2Bin(bit0));
	strcpy(&binWord[4], hexBit2Bin(bit1));
	strcpy(&binWord[8], hexBit2Bin(bit2));
	strcpy(&binWord[12], hexBit2Bin(bit3));
	binWord[16] = '\0';
	return binWord;
}

//This Function get a 16-bit binary base value (*char) and return a decimal base value (int)
int bin2Dec(char *binWord)
{
	int dec = 0;
	for (int i = 0; i < 16; i++)
	{
		int bit = 0;
		if (binWord[15 - i] == '1')bit = 1;
		dec += ((bit)*(pow(2, i)));

	}
	if (dec > 32767)
	{
		dec = (-65536 + dec);
	}
	return dec;
}

//This Function get a 4-bit hexadecimal base value (*char) and return a decimal base value (int)
int hexWord2Dec(char *hexWord)
{

	char binWord[17];
	int decNum;
	strcpy(binWord, hexWord2Bin(hexWord));
	decNum = bin2Dec(binWord);
	return decNum;
}
char *dec2Hex(int dec)
{
	if (dec < 0) dec = 65536 + dec;
	int i = 0, j, temp;
	char hex[5];
	while (dec != 0) {
		temp = dec % 16;
		//To convert integer into character
		if (temp < 10)
			temp = temp + 48; else
			temp = temp + 55;
		hex[i++] = temp;
		dec = dec / 16;
	}
	while (i < 4)
	{
		hex[i] = '0';
		i++;
	}

	hex[4] = '\0';
	strrev(hex);
	hex[4] = '\0';
	return hex;
}

//============= File Handeling Functions ==============//

//This Function checks if enough arguments were given to the program
void checkArgs(int argc)
{
	if (argc != 3)
	{
		printf("Error: %d File(s) of 2 were missing!", 2 - (argc - 1));
		printf("\nPress any key to countinue...");
		getchar();
		exit(1);
	}
}

//This Function gets a File and checks if it was opened correctly
void checkFile(FILE *file, char *name)
{
	if (file == NULL)
	{
		printf("Error: There was a problem opening %s!", name);
		printf("\nPress any key to countinue...");
		getchar();
		exit(1);
	}
}

//============= Text Decoders Functions ==============//

//this function get a reg name and return its coresponding hex bit
char decodeReg(char *reg)
{
	if (strcmp(reg, "$zero") == 0) return '0';
	if (strcmp(reg, "$at") == 0) return '1';
	if (strcmp(reg, "$v0") == 0) return '2';
	if (strcmp(reg, "$a0") == 0) return '3';
	if (strcmp(reg, "$a1") == 0) return '4';
	if (strcmp(reg, "$t0") == 0) return '5';
	if (strcmp(reg, "$t1") == 0) return '6';
	if (strcmp(reg, "$t2") == 0) return '7';
	if (strcmp(reg, "$t3") == 0) return '8';
	if (strcmp(reg, "$s0") == 0) return '9';
	if (strcmp(reg, "$s1") == 0) return 'A';
	if (strcmp(reg, "$s2") == 0) return 'B';
	if (strcmp(reg, "$gp") == 0) return 'C';
	if (strcmp(reg, "$sp") == 0) return 'D';
	if (strcmp(reg, "$fp") == 0) return 'E';
	if (strcmp(reg, "$ra") == 0) return 'F';
}

//this function get a branch command name and return its coresponding hex bit
char decodeBranch(char *reg)
{
	if (strcmp(reg, "beq") == 0) return '0';
	if (strcmp(reg, "bne") == 0) return '1';
	if (strcmp(reg, "bgt") == 0) return '2';
	if (strcmp(reg, "blt") == 0) return '3';
	if (strcmp(reg, "bge") == 0) return '4';
	if (strcmp(reg, "ble") == 0) return '5';
	if (strcmp(reg, "jr") == 0) return '6';
}

//this function get a imm and decode it to 4-bit hex digits
char *decodeImm(char *imm, Label *labelList)
{

	char immCmd[5];
	if (imm[0] == '0' && imm[1] == 'x')
	{

		char hexTest[5];
		strcpy(hexTest, strupr(&imm[2]));
		return dec2Hex(hexWord2Dec(hexTest));
	}

	else if (imm[0] == '-' || imm[0] >= '0' && imm[0] <= '9')
	{
		strcpy(immCmd, dec2Hex(atoi(imm)));
		return dec2Hex(atoi(imm));

	}
	else
	{
		for (int i = 0; i < MEM_SIZE; i++)
		{
			if (strcmp(imm, labelList[i].name) == 0)
			{
				return dec2Hex(labelList[i].pc);
			}
		}
	}

}

//======= Text Extractors & Cleaners Functions ========//

//this function get a line and extract the label name from it
Label extractLabel(char* line)
{
	Label label = { "",0 };
	int colonPos = -1, hashPos = MAX_ROW_LENGTH;
	for (int i = 0; i < MAX_ROW_LENGTH; i++)
	{
		if (line[i] == ':')
		{
			colonPos = i;
			break;
		}
	}
	for (int i = 0; i < MAX_ROW_LENGTH; i++)
	{
		if (line[i] == '#')
		{
			hashPos = i;
			break;
		}
	}
	if (colonPos != -1)
	{
		if (hashPos != -1 && colonPos < hashPos)
		{
			strncpy(label.name, line, colonPos);
			label.name[colonPos] = '\0';

			//labelList->name[colonPos] = '\0';
		}
	}
	return label;

}

//this function get a line and remove the whitespaces from it
void clearWhiteSpaces(char *line)
{
	for (int i = 0; i < MAX_ROW_LENGTH; i++)
	{
		if (strncmp(line, ".word", 5) == 0) break;
		while (line[i] == ' ' || line[i] == '\t')
		{

			for (int j = i; j < MAX_ROW_LENGTH; j++)
			{
				line[j] = line[j + 1];
			}
		}

	}
}

//this function get a line without whitespaces and extract only the command from that line
void extractCommand(char *line)
{
	int hash = 0;
	int colon = 0;
	for (int i = 0; i < MAX_ROW_LENGTH; i++)
	{
		if (line[i] == '#')
		{
			hash = 1;
			line[i] = '\0';
			i++;
		}
		if (hash != 0)line[i] = '\0';
	}
	for (int i = 0; i < MAX_ROW_LENGTH; i++)
	{
		if (line[i] == ':') colon = i + 1;
		if (colon != 0) line[i - colon + 1] = line[i + 1];
	}

}

// this function get a opcode name and return it coresponding hex char of the opcode
char extractOpcode(char *line)
{

	char cmd2[3];
	char cmd3[4];
	char cmd4[5];
	char cmd6[7];
	strncpy(cmd2, line, 2);
	cmd2[2] = '\0';
	strncpy(cmd3, line, 3);
	cmd3[3] = '\0';
	strncpy(cmd4, line, 4);
	cmd4[4] = '\0';
	strncpy(cmd6, line, 6);
	cmd6[6] = '\0';
	if (strcmp(cmd2, "or") == 0) {
		strcpy(line, &line[2]);
		return '4';
	}
	if (strcmp(cmd2, "sw") == 0) {

		strcpy(line, &line[2]);
		return 'B';
	}
	if (strcmp(cmd2, "lw") == 0) {

		strcpy(line, &line[2]);
		return 'A';
	}
	if (strcmp(cmd3, "add") == 0) {
		strcpy(line, &line[3]);
		return '0';
	}
	if (strcmp(cmd3, "sub") == 0) {
		strcpy(line, &line[3]);
		return '1';
	}
	if (strcmp(cmd3, "mul") == 0) {
		strcpy(line, &line[3]);
		return '2';
	}
	if (strcmp(cmd3, "and") == 0) {
		strcpy(line, &line[3]);
		return '3';
	}
	if (strcmp(cmd3, "sll") == 0) {
		strcpy(line, &line[3]);
		return '5';
	}
	if (strcmp(cmd3, "sra") == 0) {
		strcpy(line, &line[3]);
		return '6';
	}
	if (strcmp(cmd3, "jal") == 0) {
		strcpy(line, &line[3]);
		return '9';
	}
	if (strcmp(cmd4, "halt") == 0) {

		strcpy(line, &line[4]);
		return 'F';
	}
	if (strcmp(cmd4, "limm") == 0) {
		strcpy(line, &line[4]);
		return '7';
	}
	if (strcmp(cmd6, "branch") == 0) {

		strcpy(line, &line[6]);
		return '8';
	}

	return '?';
}

// this function get a register name and return it coresponding hex char of the register
char extractReg(char*line, int type)
{
	char reg[6];
	if (type == 0)
	{
		int i = 0;
		while (line[i] != ',') i++;
		strncpy(reg, line, i);
		reg[i] = '\0';
		if (reg[0] == '$') return decodeReg(reg);
		else return decodeBranch(reg);

	}
	if (type == 1 || type == 2)
	{
		int i = 0;
		int j = 0;
		while (line[i] != ',' || type > 0)
		{
			if (line[i] == ',')
			{
				type--;
				j = i;
			}

			i++;
		}

		strncpy(reg, &line[j + 1], i - j - 1);
		reg[i - j - 1] = '\0';
		return decodeReg(reg);

	}
}

// this function get a command line and return the imm in this line
char *extractImm(char *line)
{
	int i = 0;
	int j = 0;
	int n = 0;
	while (line[i] != '\0')
	{
		if (line[i] == ',') j = i;
		if (line[i] == '\n') n = i;
		i++;
	}
	line[n] = '\0';
	return (&line[j + 1]);
}

//============= Condition Functions =================//

// this function get a command and return 1 if its an imm command and 0 otherwise
int isImmCommand(char op, char rd)
{
	if (op == '7' || op == '9' || op == 'A' || op == 'B') return TRUE;
	if (op == '8' && rd != '6') return TRUE;
	return FALSE;
}
int isWord(char *line)
{
	for (int i = 0; i < MAX_ROW_LENGTH; i++)
	{
		if (line[i] == '.')
		{
			if (i < MAX_ROW_LENGTH - 5)
			{
				if (line[i + 1] == 'w' && line[i + 2] == 'o'&& line[i + 3] == 'r'&& line[i + 4] == 'd') return TRUE;
			}
		}
	}
	return FALSE;
}


//=============== Count Functions ===================//

// this function get a command and return its pc size
int pcSize(char *line)
{
	char cmd2[3];
	char cmd3[4];
	char cmd4[5];
	char cmd6[7];
	strncpy(cmd2, line, 2);
	cmd2[2] = '\0';
	strncpy(cmd3, line, 3);
	cmd3[3] = '\0';
	strncpy(cmd4, line, 4);
	cmd4[4] = '\0';
	strncpy(cmd6, line, 6);
	cmd6[6] = '\0';
	if (strcmp(cmd2, "or") == 0) return 1;
	if (strcmp(cmd2, "sw") == 0 || strcmp(cmd2, "lw") == 0) return 2;
	if (strcmp(cmd3, "add") == 0 || strcmp(cmd3, "sub") == 0 || strcmp(cmd3, "mul") == 0 || strcmp(cmd3, "and") == 0 || strcmp(cmd3, "sll") == 0 || strcmp(cmd3, "sra") == 0) return 1;
	if (strcmp(cmd3, "jal") == 0) return 2;
	if (strcmp(cmd4, "halt") == 0) return 1;
	if (strcmp(cmd4, "limm") == 0) return 2;
	if (strcmp(cmd6, "branch") == 0 && line[6] == 'j'&& line[7] == 'r') return 1;
	if (strcmp(cmd6, "branch") == 0) return 2;
	return 0;

}

//=========== Memrory Storing Functions =============//

// this function get memory line, pc and command and store it in the main memory array
void storeCommand(int pc, Memory *mem, char op, char rd, char rs, char rt)
{
	Memory cmdMem;

	char cmd[5];
	cmd[0] = op;
	cmd[1] = rd;
	cmd[2] = rs;
	cmd[3] = rt;
	cmd[4] = '\0';
	strcpy(cmdMem.mem, cmd);
	cmdMem.active = TRUE;
	mem[pc] = cmdMem;
}

// this function get memory line, pc and imm and store it in the main memory array
void storeImm(int pc, Memory *mem, char imm[5])
{
	Memory immMem;
	strcpy(immMem.mem, imm);
	immMem.active = TRUE;
	mem[pc] = immMem;
}

// this function get memory line and word and store it in the main memory array
void storeWord(Memory *mem, char *word)
{
	char newWord[MAX_ROW_LENGTH];
	Memory wordMem;
	int i = 0;
	int j;
	int pcDec;
	while (word[i] != ' ')i++;
	j = i + 1;
	while (word[j] != '\n' && word[j] != '\0')j++;
	char pc[MAX_ROW_LENGTH];
	strcpy(pc, word);
	pc[i] = '\0';

	if (pc[0] == '0' && pc[1] == 'x') pcDec = hexWord2Dec(strupr(&pc[2]));
	else pcDec = atoi(pc);
	strcpy(newWord, &word[i + 1]);

	newWord[j - i - 1] = '\0';
	if (newWord[0] == '0' && newWord[1] == 'x') strcpy(newWord, dec2Hex(hexWord2Dec(strupr(&newWord[2]))));
	else strcpy(newWord, dec2Hex(atoi(newWord)));
	strcpy(wordMem.mem, newWord);
	wordMem.active = TRUE;
	mem[pcDec] = wordMem;
}

int main(int argc, char* argv[])
{
	//========= Input Verification & Handeling ==========//
	checkArgs(argc);											//Check if enough files were loaded
	FILE *asm_file = NULL, *memin = NULL;						//Create file Pointers
	asm_file = fopen(argv[1], "r");								//Open file program.asm 
	memin = fopen(argv[2], "w");								//Open file memin.txt
	checkFile(asm_file, argv[1]);								//Check file program.asm
	checkFile(memin, argv[2]);									//Check file memin.txt

//============= Initialize Parameters ==============//
	int pc = 0;													//Initializing PC counter
	Label labelArray[MEM_SIZE];									//Initializing Labels Array where Labels names and PC will be stored
	int labelArrayIndex = 0;									//Initailizing Labels Array Index to know where to store the next Label
	char line[MAX_ROW_LENGTH];									//Initailizing an empty line to start reading the .asm file

//============ First Run - Label Handeling =============//
	while (!feof(asm_file))
	{
		fgets(line, MAX_ROW_LENGTH, asm_file);					//Reading a line from the file and store
		line[MAX_ROW_LENGTH - 1] = '\n';
		clearWhiteSpaces(line);									//Clear all tabs and spaces from line
		char rawLine[MAX_ROW_LENGTH];							//
		strcpy(rawLine, line);
		extractCommand(line);

		Label label = extractLabel(rawLine);
		label.pc = pc;

		pc += pcSize(line);

		if (strcmp(label.name, "") != 0 && label.name[0] != '\n')
		{

			labelArray[labelArrayIndex] = label;
			labelArrayIndex++;
		}

	}
	//======== Second Run - Memory Image Writing =========//

	rewind(asm_file);

	Memory memList[MEM_SIZE];
	pc = 0;
	while (!feof(asm_file))
	{
		fgets(line, MAX_ROW_LENGTH, asm_file);

		line[MAX_ROW_LENGTH - 1] = '\n';
		clearWhiteSpaces(line);
		extractCommand(line);

		if (isWord(line) == FALSE && line[0] != ' ' && line[0] != '\t' &&line[0] != "" &&line[0] != '\0'&&line[0] != '\n')
		{
			char tmpline[MAX_ROW_LENGTH];
			strcpy(tmpline, line);
			char op = extractOpcode(tmpline);
			char rd = extractReg(tmpline, 0);
			char rs = extractReg(tmpline, 1);
			char rt = extractReg(tmpline, 2);
			storeCommand(pc, memList, op, rd, rs, rt);
			pc++;

			if (isImmCommand(op, rd) == TRUE)
			{

				storeImm(pc, memList, decodeImm(extractImm(line), labelArray));
				pc++;
			}
		}

		if (isWord(line) == TRUE)
		{
			storeWord(memList, &line[6]);
		}
	}
	int lastMemIndex = 0;
	for (int i = 0; i < MEM_SIZE; i++)
	{
		if (memList[i].active == TRUE) lastMemIndex = i;
	}
	lastMemIndex++;
	for (int i = 0; i < lastMemIndex; i++)
	{
		if (memList[i].active != TRUE)
		{
			Memory emptyMem = { "0000",TRUE };
			memList[i] = emptyMem;
		}
	}
	for (int i = 0; i < lastMemIndex; i++)
	{

		fprintf(memin, "%s\n", memList[i].mem);
	}
	fclose(asm_file);
	fclose(memin);

	return 0;
}
